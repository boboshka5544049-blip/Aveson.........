# AVESON V9

AVESON V9 — artist + admin + release workflow, with Android app and Node.js/PostgreSQL backend prototype.

## Android project

The Android project is in:

```text
AVESON_V9/android/
  settings.gradle
  build.gradle
  app/
```

## GitHub Actions

Workflow:

```text
.github/workflows/build-apk.yml
```

It builds a debug APK and uploads it as the artifact **AVESON-V9-APK**.

### Important GitHub upload rule

Do **not** paste the folder tree into `.github/workflows/main.yml`.

The repository should contain real files, for example:

```text
AVESON_V9/
├── android/
│   ├── settings.gradle
│   ├── build.gradle
│   └── app/
├── backend/
└── .github/
    └── workflows/
        └── build-apk.yml
```

If using the ZIP, extract it first and upload the extracted files/folders to the repository.

## Backend

```text
backend/
  server.js
  package.json
  migrate.js
  seed.js
  sql/schema.sql
```

The Android app in this V9 package is currently a local/demo client; the backend is included as the server-side foundation for the next integration step.
