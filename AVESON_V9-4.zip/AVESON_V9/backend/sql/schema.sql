CREATE TABLE IF NOT EXISTS users(
 id BIGSERIAL PRIMARY KEY,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'artist' CHECK(role IN ('artist','admin')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS releases(
 id BIGSERIAL PRIMARY KEY,
 artist_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL,
 version TEXT NOT NULL DEFAULT 'Single',
 genre TEXT NOT NULL,
 release_date DATE NOT NULL,
 audio_name TEXT NOT NULL,
 cover_name TEXT NOT NULL,
 audio_path TEXT,
 cover_path TEXT,
 audio_bytes BIGINT,
 cover_bytes BIGINT,
 status TEXT NOT NULL DEFAULT 'Pending Review' CHECK(status IN ('Pending Review','Metadata Check','Approved','Rejected','In Distribution','Delivered')),
 admin_note TEXT NOT NULL DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS royalty_entries(
 id BIGSERIAL PRIMARY KEY,
 release_id BIGINT REFERENCES releases(id) ON DELETE SET NULL,
 artist_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 platform TEXT NOT NULL,
 territory TEXT NOT NULL DEFAULT 'Worldwide',
 period TEXT NOT NULL,
 streams BIGINT NOT NULL DEFAULT 0,
 gross NUMERIC(14,4) NOT NULL DEFAULT 0,
 net NUMERIC(14,4) NOT NULL DEFAULT 0,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS rights_cases(
 id BIGSERIAL PRIMARY KEY,
 release_id BIGINT REFERENCES releases(id) ON DELETE SET NULL,
 artist_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 case_type TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Open',
 note TEXT NOT NULL DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS distribution_jobs(
 id BIGSERIAL PRIMARY KEY,
 release_id BIGINT NOT NULL REFERENCES releases(id) ON DELETE CASCADE,
 target TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Queued',
 external_id TEXT,
 note TEXT NOT NULL DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
